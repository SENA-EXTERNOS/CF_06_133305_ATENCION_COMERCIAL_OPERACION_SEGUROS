function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5nPR7ojuUFK":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

